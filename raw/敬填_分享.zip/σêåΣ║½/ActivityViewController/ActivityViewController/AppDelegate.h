//
//  AppDelegate.h
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

