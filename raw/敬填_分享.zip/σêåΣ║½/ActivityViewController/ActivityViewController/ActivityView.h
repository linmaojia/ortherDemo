//
//  ActivityViewController.h
//  ActivityViewController
//
//  Created by Mac on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivityView : UIView

@property (nonatomic,strong)NSMutableArray *shareArray;
-(void)activityViewLoad;
-(void)bloakEvent;

@end
