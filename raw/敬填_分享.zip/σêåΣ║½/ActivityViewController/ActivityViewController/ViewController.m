//
//  ViewController.m
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "ViewController.h"
#import "ActivityView.h"
#import "WeboActivity.h"
#import "QQActivity.h"
#import "WXFriend.h"
#import "WXCircleOfFriends.h"
#import "CopyLinkActivity.h"
#import "RefreshActivity.h"
#import "MBProgressHUD.h"

@interface ViewController ()
{
    MBProgressHUD *HUD;
}
@property (nonatomic,strong)ActivityView *AView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.AView = [[ActivityView alloc] init];
    
   NSString *path = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"IMG_0169.jpg"];
    
    QQActivity *QActive = [QQActivity new];
    [QActive dealWithShareData:QQAPPID type:QQShareWithLinkOrVideo text:@"我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524 " title:@"口语通" description:@"我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524" flashURL:@""  previewImageURL:@"http://pic13.nipic.com/20110415/1369025_121513630398_2.jpg" actionUrl:@"http://kyt.jxt189.com/"];
    
    WeboActivity *WBActive = [WeboActivity new];
    [WBActive dealWithShareData:WBAPPID type:WeboShareWithImage text:@"我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524" title:@"口语通" description:@"我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524" objectID:@"1234" thumbnailUrl:@"http://pic13.nipic.com/20110415/1369025_121513630398_2.jpg" actionUrl:@"http://kyt.jxt189.com/"];
    
    WXFriend *WCFriend = [WXFriend new];
    [WCFriend dealWithShareData:WXAPPID type:WeChatShareWithText text:@"我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524" title:@"口语通" description:@"我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524" thumbUrl:@"http://pic13.nipic.com/20110415/1369025_121513630398_2.jpg" actionUrl:@"http://kyt.jxt189.com/"];
    
    WXCircleOfFriends *WCCirOfFriend = [[WXCircleOfFriends alloc] init];
    [WCCirOfFriend dealWithShareData:WXAPPID type:WeChatShareWithText text:@"我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524" title:@"口语通" description:@"我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524" thumbUrl:@"http://pic13.nipic.com/20110415/1369025_121513630398_2.jpg" actionUrl:@"http://kyt.jxt189.com/"];
    
    CopyLinkActivity *CLActive = [CopyLinkActivity new];
    CLActive.pasteString = @"http://m.wufazhuce.com/one/1391";
    
    CLActive.PasteBlock = ^(UIPasteboard *pab){
        if (pab != nil) {
            [self showTextDialog:@"复制成功"];
        }else{
            [self showTextDialog:@"复制失败"];
        }
    };
    
    [self.AView.shareArray addObject:WCFriend];
    [self.AView.shareArray addObject:WCCirOfFriend];
    [self.AView.shareArray addObject:WBActive];
    [self.AView.shareArray addObject:QActive];
    [self.AView.shareArray addObject:CLActive];
    [self.AView.shareArray addObject:[RefreshActivity new]];
    
    [self.view addSubview:self.AView];
  
}

//显示提示框
-(void) showTextDialog:(NSString*) str{
    
    HUD = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    HUD.bezelView.color = [UIColor blackColor];
    HUD.mode = MBProgressHUDModeText; //只显示label
    
    HUD.label.text = str;
    HUD.label.textColor = [UIColor whiteColor];
    
    //延迟1秒时间
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        // Do something...
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        HUD = nil;
        [HUD removeFromSuperview];
    });
    
}

//按钮
- (IBAction)btn:(id)sender {
    
    [self.AView activityViewLoad];
    
}

@end
