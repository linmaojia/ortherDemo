//
//  ActivityViewController.m
//  ActivityViewController
//
//  Created by Mac on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "ActivityView.h"
#import "WeboActivity.h"
#import "QQActivity.h"
#import "WeChatActivity.h"
#import "CopyLinkActivity.h"
#import "RefreshActivity.h"

@interface ActivityView ()
{
    UIActivityViewController *AVController;
}
@property (nonatomic,strong) UIViewController *SVController;
@end

@implementation ActivityView

//懒加载
-(NSMutableArray *)shareArray{
    if (!_shareArray) {
        _shareArray = [NSMutableArray array];
    }
    return _shareArray;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {}
    return self;
}

#pragma mark------UIActivityViewController
-(void)activityViewLoad{
  
    //    NSString *info = @"share test";
    //    UIImage *image=[UIImage imageNamed:@"1.png"];
    //    NSURL *url = [NSURL URLWithString:@"http://www.baidu.com"];
    
    NSLog(@"%@",self.shareArray);
    
    NSArray *postItems=@[];
    NSLog(@"self.shareArray = %@",self.shareArray);
    AVController = [[UIActivityViewController alloc] initWithActivityItems:postItems applicationActivities:self.shareArray];
    
    //excludedActivityTypes这个数组就是用来指定不需要那些服务的
    AVController.excludedActivityTypes = @[UIActivityTypePostToFacebook,UIActivityTypeMail, UIActivityTypeAddToReadingList, UIActivityTypeAssignToContact];

#pragma mark------
    //iPhone设备
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        [[self viewController] presentViewController:AVController animated:YES completion:nil];
    }
    //iPad设备
    else {
        AVController.modalPresentationStyle = UIModalPresentationPopover;
        // 设置箭头方向
        AVController.popoverPresentationController.permittedArrowDirections = UIPopoverArrowDirectionUp;
        //设置参考系
        AVController.popoverPresentationController.sourceView = self;
        //设置箭头指向的对象
//        AVController.popoverPresentationController.sourceRect = ;
        //展现popVC
        [[self viewController] presentViewController:AVController animated:YES completion:nil];
    }
    
    //只做一次
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
     [self bloakEvent]; //BLOCK事件
    });
}

//block处理事件
-(void)bloakEvent{
    
        NSLog(@"event = %@",self.shareArray);
        
        for (id activityItem in self.shareArray) {
            
            if ([activityItem isKindOfClass:[WeChatActivity class]]) {
                WeChatActivity *wcActivity = activityItem;
                wcActivity.customBlock = ^{
                    NSLog(@"微信");
                };
            }
            
            if ([activityItem isKindOfClass:[WeboActivity class]]) {
                WeboActivity *wbActivity = activityItem;
                wbActivity.customBlock = ^{
                    NSLog(@"微博");
                };
            }
            if ([activityItem isKindOfClass:[QQActivity class]]) {
                QQActivity *qqActivity = activityItem;
                qqActivity.customBlock = ^{
                    NSLog(@"QQ");
                };
            }
            if ([activityItem isKindOfClass:[CopyLinkActivity class]]) {
                CopyLinkActivity *clActivity = activityItem;
                clActivity.customBlock = ^{
                    NSLog(@"复制");
                };
            }
            if ([activityItem isKindOfClass:[RefreshActivity class]]) {
                RefreshActivity *rfActivity = activityItem;
                rfActivity.customBlock = ^{
                    NSLog(@"刷新");
                };
            }
            
        }
    
}

//获取父视图控制器
- (UIViewController *)viewController
{
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder *nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            NSLog(@"ssss");
            return (UIViewController *)nextResponder;
        }
    }
    return nil;
}

@end
