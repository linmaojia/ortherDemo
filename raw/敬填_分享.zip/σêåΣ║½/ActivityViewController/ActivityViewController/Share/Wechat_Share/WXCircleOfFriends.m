//
//  WXCircleOfFriends.m
//  ActivityViewController
//
//  Created by Mac on 16/7/6.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "WXCircleOfFriends.h"

@implementation WXCircleOfFriends

-(UIImage *)activityImage{
    return [UIImage imageNamed:@"share_moments"];
}

-(NSString *)activityTitle{
    return @"微信朋友圈";
}

-(void)prepareWithActivityItems:(NSArray *)activityItems{
    
    NSLog(@"WX-分享朋友圈");
    self.sceneStyle = WXSceneTimeline; //朋友圈
    
}

@end
