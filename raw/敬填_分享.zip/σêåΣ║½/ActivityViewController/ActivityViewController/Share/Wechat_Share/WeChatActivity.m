//
//  WeChatActivity.m
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "WeChatActivity.h"
#import "WechatAuthSDK.h"

@interface WeChatActivity()
@property (nonatomic,strong)NSDictionary *shareDic; //保存分享的数据
@end

@implementation WeChatActivity

//-(UIImage *)activityImage{
//    return [UIImage imageNamed:@"share_wechat"];
//}
//
//-(NSString *)activityTitle{
//   return @"微信";
//}

//handurl
-(void)handleOpenURL:(NSURL *)url{
    if ([WXApi handleOpenURL:url delegate:self]) {
        NSLog(@"WX-成功处理跳转");
    }else{
        NSLog(@"WX-处理跳转失败");
    }
}
//微信分享
- (void)SendMessageToWXReq:(NSString *)WXID type:(WechatShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description thumbUrl:(NSString *)thumbUrl actionUrl:(NSString *)actionUrl{

    //注册
    if ([WXApi registerApp:WXID]) {
        NSLog(@"微信注册成功");
    }
    else{
        NSLog(@"微信注册失败");
    }

#pragma mark----判断检测
    if ([WXApi isWXAppInstalled] == NO) {
        NSLog(@"未安装微信客户端，分享失败");
        return;
    }
    if ([WXApi isWXAppSupportApi] == NO) {
        NSLog(@"当前微信的版本不支持OpenApi");
        return;
    }
    
    //创建发送对象实例
    SendMessageToWXReq *sendReq = [[SendMessageToWXReq alloc] init];
    
    //scene
//    if (scene == WXSceneSession) {
//        NSLog(@"跳转到微信好友");
        sendReq.scene = self.sceneStyle; //跳转到微信好友或朋友圈
//    }else if (scene == WXSceneTimeline){
//        NSLog(@"跳转到微信朋友圈");
//        sendReq.scene = WXSceneTimeline; //跳转到微信朋友圈
//    }
    
    //分享内容对象
    WXMediaMessage *urlMessage = nil;
    
    if (type != WeChatShareWithText) {
        //多媒体内容
        NSLog(@"WX-多媒体内容");
        sendReq.bText = NO;
        //创建分享内容对象
        urlMessage = [WXMediaMessage message];
        urlMessage.title = title;//分享标题
        urlMessage.description = description;//分享描述
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:thumbUrl]];
        if (data == nil) {
            data = [NSData dataWithContentsOfFile:thumbUrl];
            
            NSLog(@"%@",[NSString stringWithFormat:@"WX本地地址thumbUrl = %@",thumbUrl]);
        }
        
        //进行缩略图片大小检测(KB)
        UIImage *thumbImg = [self dealImageCompress:data];
        
        NSLog(@"size = %@",[NSValue valueWithCGSize:thumbImg.size]);
        
        #pragma mark-----分享的缩略图不能超过了32k
        [urlMessage setThumbImage:thumbImg];//缩略图
    }
    
    //    0=纯文本 1=纯图片 2=新闻类链接 3=音频 4=视频
    //创建多媒体对象
    switch (type) {
        case WeChatShareWithText:
        {
            //文本内容
            NSLog(@"WX-文本内容");
            sendReq.bText = YES;
            sendReq.text = text;
        }
            break;
        case WeChatShareWithImage:
        {
            NSLog(@"WX-图片地址");
            //图片地址
            WXImageObject *imageObj = [WXImageObject object];
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:actionUrl]];
            
            if (data == nil) {
                //本地图片
                data = [NSData dataWithContentsOfFile:actionUrl];
                
                NSLog(@"%@",[NSString stringWithFormat:@"WX本地地址actionUrl = %@",actionUrl]);
            }
            
            imageObj.imageData = data;
            urlMessage.mediaObject = imageObj;
        }
            break;
        case WeChatShareWithLink:
        {
            
            NSLog(@"WX-链接");
            //链接
            WXWebpageObject *pageObj = [WXWebpageObject object];
            pageObj.webpageUrl = actionUrl;
            urlMessage.mediaObject = pageObj;
        }
            break;
        case WeChatShareWithAudio:
        {
            NSLog(@"WX-音乐地址");
            //音乐地址
            WXMusicObject *musicObj = [WXMusicObject object];
            musicObj.musicUrl = actionUrl;
            musicObj.musicLowBandUrl = musicObj.musicUrl;
            urlMessage.mediaObject = musicObj;
        }
            break;
        case WeChatShareWithVideo:
        {
            NSLog(@"WX-视频地址");
            //视频地址
            WXVideoObject *videoObj = [WXVideoObject object];
            videoObj.videoUrl = actionUrl;
            videoObj.videoLowBandUrl = videoObj.videoUrl;//低分辨率的视频url
            urlMessage.mediaObject = videoObj;
        }
            break;
        default:
            break;
    }
    
    sendReq.message = urlMessage;
    
    if([WXApi sendReq:sendReq]){
        NSLog(@"WX-发送成功");
    }else{
        NSLog(@"WX-发送失败");
    }
}

/*! @brief 发送一个sendReq后，收到微信的回应
 *
 * 收到一个来自微信的处理结果。调用一次sendReq后会收到onResp。
 * 可能收到的处理结果有SendMessageToWXResp、SendAuthResp等。
 * @param resp具体的回应内容，是自动释放的
 */
- (void)onResp:(BaseResp *)resp {

    //微信分享/收藏
    if ([resp isKindOfClass:[SendMessageToWXResp class]]){
        SendMessageToWXResp *sendResp = (SendMessageToWXResp *)resp;
        
        NSLog(@"微信分享");
        
        @try {
            switch (sendResp.errCode) {
                case WXSuccess:
                {
                    //成功
                    NSLog(@"微信分享-成功");
                }
                    break;
                case WXErrCodeUserCancel:
                {
                    //用户取消
                    NSLog(@"微信分享-用户取消分享");
                }
                    break;
                case WXErrCodeSentFail:
                {
                    //发送失败
                    NSLog(@"微信分享-发送失败");
                }
                    break;
                case WXErrCodeAuthDeny:
                {
                    //授权失败
                    NSLog(@"微信分享-授权失败");
                }
                    break;
                default:
                {
                    //微信不支持
                    NSLog(@"微信分享-微信不支持");
                }
                    break;
            }
            
        } @catch (NSException *e) {
            NSLog(@"%@",[NSString stringWithFormat:@"WXShare_Exception = %@",e]);
        }
        
    }
    
}

//真正进行回应
//执行分享行为
-(void)performActivity{
 
    NSString *WXID = self.shareDic[@"WXID"];
    int type = [self.shareDic[@"type"] intValue];
//    int scene = [self.shareDic[@"scene"] intValue];
    NSString *text = self.shareDic[@"text"];
    NSString *title = self.shareDic[@"title"];
    NSString *description = self.shareDic[@"description"];
    NSString *thumbUrl = self.shareDic[@"thumbUrl"];
    NSString *actionUrl = self.shareDic[@"actionUrl"];
    
    [self SendMessageToWXReq:WXID type:type text:text title:title description:description thumbUrl:thumbUrl actionUrl:actionUrl];
    
    [self activityDidFinish:YES];

}

//处理图片压缩
-(UIImage *)dealImageCompress:(NSData *)data{
   
    CGFloat length = [data length]/1000;
    NSLog(@"length = %f",length);
    //分享的缩略图不能超过了32k
    if (length > 32) {
       return [self imageCompressForSize:[UIImage imageWithData:data] targetSize:CGSizeMake(150, 150)];
    }

    return [UIImage imageWithData:data];
}

//压缩方法
-(UIImage *) imageCompressForSize:(UIImage *)sourceImage targetSize:(CGSize)size{
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = size.width;
    CGFloat targetHeight = size.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0, 0.0);
    if(CGSizeEqualToSize(imageSize, size) == NO){
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        if(widthFactor > heightFactor){
            scaleFactor = widthFactor;
        }
        else{
            scaleFactor = heightFactor;
        }
        scaledWidth = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        if(widthFactor > heightFactor){
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }else if(widthFactor < heightFactor){
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    
    UIGraphicsBeginImageContext(size);
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    [sourceImage drawInRect:thumbnailRect];
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil){
        NSLog(@"scale image fail");
    }
    UIGraphicsEndImageContext();
    return newImage;
}

//处理传过来的分享数据
-(void)dealWithShareData:(NSString *)WXID type:(WechatShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description thumbUrl:(NSString *)thumbUrl actionUrl:(NSString *)actionUrl{
  
   self.shareDic = @{@"WXID":WXID,@"type":@(type),@"text":text,@"title":title,@"description":description,@"thumbUrl":thumbUrl,@"actionUrl":actionUrl};
}

@end
