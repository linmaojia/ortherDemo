//
//  WeChatActivity.h
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "CustomActivity.h"
#import "WXApi.h"

@interface WeChatActivity : CustomActivity<WXApiDelegate>

typedef NS_ENUM(NSInteger, WeChatScene){
    WeChatSceneSession  = 0,   /**< 聊天界面    */
    WeChatSceneTimeline = 1,  /**< 朋友圈      */
    WeChatSceneFavorite = 2  /**< 收藏        */
};

//0=纯文本 1=纯图片 2=新闻类链接 3=音频 4=视频
typedef NS_ENUM(NSInteger, WechatShareStyle){
   
    WeChatShareWithText = 0,       /**< 分享纯文本    */
    WeChatShareWithImage = 1,     /**< 分享纯图片    */
    WeChatShareWithLink = 2,     /**< 分享新闻类链接    */
    WeChatShareWithAudio = 3,   /**< 分享音频    */
    WeChatShareWithVideo = 4   /**< 分享视频   */
};

@property (nonatomic,assign)enum WXScene sceneStyle;

-(void)handleOpenURL:(NSURL *)url; //handurl

-(void)dealWithShareData:(NSString *)WXID type:(WechatShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description thumbUrl:(NSString *)thumbUrl actionUrl:(NSString *)actionUrl;

@end
