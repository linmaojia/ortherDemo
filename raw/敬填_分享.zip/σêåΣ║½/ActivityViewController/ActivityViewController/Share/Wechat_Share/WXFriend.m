//
//  WXFriend.m
//  ActivityViewController
//
//  Created by Mac on 16/7/6.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "WXFriend.h"

@implementation WXFriend

-(UIImage *)activityImage{
    return [UIImage imageNamed:@"share_wechat"];
}

-(NSString *)activityTitle{
    return @"微信好友";
}

-(void)prepareWithActivityItems:(NSArray *)activityItems{
    
    NSLog(@"WX-分享朋友列表");
    self.sceneStyle = WXSceneSession; //朋友列表

}

@end