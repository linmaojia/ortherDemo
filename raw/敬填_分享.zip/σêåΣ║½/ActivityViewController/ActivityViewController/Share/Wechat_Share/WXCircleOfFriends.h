//
//  WXCircleOfFriends.h
//  ActivityViewController
//
//  Created by Mac on 16/7/6.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "WeChatActivity.h"

@interface WXCircleOfFriends : WeChatActivity

@end
