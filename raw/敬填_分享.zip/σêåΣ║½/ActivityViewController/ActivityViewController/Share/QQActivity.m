//
//  QQActivity.m
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "QQActivity.h"
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>

@interface QQActivity()<QQApiInterfaceDelegate,TencentSessionDelegate>
{
    TencentOAuth *auth;
}
@property (nonatomic,strong)NSDictionary *shareDic; //保存分享的数据

@end
@implementation QQActivity

//分享框的图片
-(UIImage *)activityImage{    
    return [UIImage imageNamed:@"share_moments"];
}

-(NSString *)activityTitle{
  return @"QQ";
}

//handurl
-(void)handleOpenURL:(NSURL *)url{
    if([QQApiInterface handleOpenURL:url delegate:self]){
        NSLog(@"QQ-成功处理跳转");
    }else{
        NSLog(@"QQ-不支持的请求协议或处理失败");
    }
}

//分享方法
-(void)SendMessageToQQReq:(NSString *)QQID type:(QQShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description flashURL:(NSString *)flashURL previewImageURL:(NSString *)previewImageURL actionUrl:(NSString *)actionUrl{
    
    //注册
    auth = [[TencentOAuth alloc] initWithAppId:QQID andDelegate:self];
    
#pragma mark----判断检测
    if ([TencentOAuth iphoneQQInstalled] == NO) {
        NSLog(@"未安装QQ客户端");
        return;
    }
    
#pragma mark---其他类URL
    //网络地址URL
    NSURL *actionURL = [NSURL URLWithString:actionUrl];
    if ([NSData dataWithContentsOfURL:actionURL] == nil) {
        //本地地址URL
        actionURL = [NSURL fileURLWithPath:actionUrl];
    }
#pragma mark---缩略图URL
    //网络地址URL
    NSURL *imageURL = [NSURL URLWithString:previewImageURL];
    NSLog(@"%@",[NSString stringWithFormat:@"imageURL = %@",imageURL]);
    //imgData
    NSData *imgData = [NSData dataWithContentsOfURL:imageURL];
    if (imgData == nil) {
        //本地地址URL
        imageURL = [NSURL fileURLWithPath:previewImageURL];
        //imgData
        imgData = [NSData dataWithContentsOfFile:previewImageURL];
        
        NSLog(@"%@",[NSString stringWithFormat:@"QQ本地地址previewImageURL = %@",previewImageURL]);
    }
    
    switch (type) {
        case QQShareWithText:
        {
            NSLog(@"QQ-分享纯文本");
            //纯文本
            QQApiTextObject *textObj = [QQApiTextObject objectWithText:text];
            SendMessageToQQReq *req = [SendMessageToQQReq reqWithContent:textObj];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                QQApiSendResultCode resultCode = [QQApiInterface sendReq:req];
                //发送后的返回码
                NSLog(@"%@",[NSString stringWithFormat:@"QQSendResultCode = %d",resultCode]);
            });
        }
            break;
        case QQShareWithImage:
        {
            NSLog(@"QQ-分享纯图片");
            
            //纯图片分享
            QQApiImageObject *imgObj = [QQApiImageObject objectWithData:imgData previewImageData:imgData title:title description:description];
            SendMessageToQQReq *req = [SendMessageToQQReq reqWithContent:imgObj];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                QQApiSendResultCode resultCode = [QQApiInterface sendReq:req];
                //发送后的返回码
                NSLog(@"%@",[NSString stringWithFormat:@"QQSendResultCode = %d",resultCode]);
            });
        }
            break;
        case QQShareWithLinkOrVideo:
        {
            NSLog(@"QQ-分享新闻类data");
            
            //新闻类分享/视频
            QQApiNewsObject *newsObj = [QQApiNewsObject objectWithURL:actionURL title:title description:description previewImageData:imgData];
            
            //将内容分享到qq
            SendMessageToQQReq *req = [SendMessageToQQReq reqWithContent:newsObj];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                QQApiSendResultCode resultCode = [QQApiInterface sendReq:req];
                //发送后的返回码
                NSLog(@"%@",[NSString stringWithFormat:@"QQSendResultCode = %d",resultCode]);
            });
            
            
        }
            break;
        case QQShareWithAudio:
        {
            NSLog(@"QQ-分享音频");
            //音频分享
            QQApiAudioObject *audioObj = [QQApiAudioObject objectWithURL:actionURL title:title description:description previewImageData:imgData];
            
            
            NSURL *flashUrl = [NSURL URLWithString:flashURL];
            if ([NSData dataWithContentsOfURL:flashUrl] == nil) {
                flashUrl = [NSURL fileURLWithPath:flashURL];
            }
            //设置播放流媒体地址
            [audioObj setFlashURL:flashUrl];
            
            //将内容分享到qq
            SendMessageToQQReq *req = [SendMessageToQQReq reqWithContent:audioObj];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                QQApiSendResultCode resultCode = [QQApiInterface sendReq:req];
                //发送后的返回码
                NSLog(@"%@",[NSString stringWithFormat:@"QQSendResultCode = %d",resultCode]);
            });
            
        }
            break;
        default:
            break;
    }
    
}

/**
 * 登录成功后的回调
 */
- (void)tencentDidLogin{}

/**
 * 登录失败后的回调
 * \param cancelled 代表用户是否主动退出登录
 */
- (void)tencentDidNotLogin:(BOOL)cancelled{}

/**
 * 登录时网络有问题的回调
 */
- (void)tencentDidNotNetWork{}

/**
 处理来至QQ的请求
 */
- (void)onReq:(QQBaseReq *)req{
}

/**
 处理来至QQ的响应
 */
- (void)onResp:(QQBaseResp *)resp{
    
    @try {
        switch (resp.type) {
            case ESENDMESSAGETOQQRESPTYPE:
            {
                SendMessageToQQResp* sendResp = (SendMessageToQQResp*)resp;
                
                NSLog(@"%@",[NSString stringWithFormat:@"result = %@",sendResp.result]);
                
                if ([sendResp.result isEqualToString:@"0"]) {
                    NSLog(@"QQ分享-成功");
                }else{
                    NSLog(@"QQ分享-失败");
                }
            }
                break;
                
            default:
                NSLog(@"未知错误");
                break;
        }
    } @catch (NSException *e) {
        NSLog(@"%@",[NSString stringWithFormat:@"QQShare_Exception = %@",e]);
    }
    
}

/**
 处理QQ在线状态的回调
 */
- (void)isOnlineResponse:(NSDictionary *)response{}

//真正进行回应
//执行分享行为
-(void)performActivity{
    
    NSString *QQID = self.shareDic[@"QQID"];
    int type = [self.shareDic[@"type"] intValue];
    NSString *text = self.shareDic[@"text"];
    NSString *title = self.shareDic[@"title"];
    NSString *description = self.shareDic[@"description"];
    NSString *flashURL = self.shareDic[@"flashURL"];
    NSString *previewImageURL = self.shareDic[@"previewImageURL"];
    NSString *actionUrl = self.shareDic[@"actionUrl"];
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
    
       [self SendMessageToQQReq:QQID type:type text:text title:title description:description flashURL:flashURL previewImageURL:previewImageURL actionUrl:actionUrl];
        
    });
    
   [self activityDidFinish:YES];
}

//处理传过来的分享数据
-(void)dealWithShareData:(NSString *)QQID type:(QQShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description flashURL:(NSString *)flashURL previewImageURL:(NSString *)previewImageURL actionUrl:(NSString *)actionUrl {
    
    self.shareDic = @{@"QQID":QQID,@"type":@(type),@"text":text,@"title":title,@"description":description,@"flashURL":flashURL,@"previewImageURL":previewImageURL,@"actionUrl":actionUrl};
    
}

@end
