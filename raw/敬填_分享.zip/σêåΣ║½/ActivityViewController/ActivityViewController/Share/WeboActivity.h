//
//  WeboActivity.h
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "CustomActivity.h"

@interface WeboActivity : CustomActivity

//0=图片内容 1=新闻类链接 2=音频 3=视频
typedef NS_ENUM(NSInteger, WeboShareStyle){
    
    WeboShareWithImage = 0,       /**< 分享图片内容    */
    WeboShareWithLink = 1,     /**< 分享新闻类链接    */
    WeboShareWithAudio = 2,     /**< 分享音频    */
    WeboShareWithVideo = 3,   /**< 分享视频    */
};

-(void)handleOpenURL:(NSURL *)url; //HandUrl

-(void)dealWithShareData:(NSString *)WBID type:(WeboShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description objectID:(NSString *)objectID thumbnailUrl:(NSString *)thumbnailUrl actionUrl:(NSString *)actionUrl;

@end
