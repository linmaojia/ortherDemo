//
//  WeboActivity.m
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "WeboActivity.h"
#import "WeiboSDK.h"

@interface WeboActivity()<WeiboSDKDelegate>
@property (nonatomic,strong)NSDictionary *shareDic; //保存分享的数据
@end

@implementation WeboActivity

-(UIImage *)activityImage{
    return [UIImage imageNamed:@"share_weibo"];
}

-(NSString *)activityTitle{
    return @"微博";
}

//handurl
-(void)handleOpenURL:(NSURL *)url{
    if ([WeiboSDK handleOpenURL:url delegate:self]) {
        NSLog(@"WB-成功处理跳转");
    }else{
       NSLog(@"WB-处理跳转失败");
    }
}

//微博分享
-(void)SendMessageToWeiboReq:(NSString *)WBID type:(WeboShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description objectID:(NSString *)objectID thumbnailUrl:(NSString *)thumbnailUrl actionUrl:(NSString *)actionUrl{
    
    [WeiboSDK enableDebugMode:YES];
    //注册
    if ([WeiboSDK registerApp:WBID]) {
        NSLog(@"微博注册成功");
    }else{
        NSLog(@"微博注册失败");
    }
    
#pragma mark----判断检测
    if (![WeiboSDK isWeiboAppInstalled]) {
        NSLog(@"未安装新浪微博客户端");
        return;
    }
    if (![WeiboSDK isCanShareInWeiboAPP]) {
        NSLog(@"用户不可以通过微博客户端进行分享");
        return;
    }
    if(![WeiboSDK isCanSSOInWeiboApp]){
        NSLog(@"用户不可以使用微博客户端进行SSO授权");
        return;
    }
    
#pragma mark---图片URL(包含缩略图)
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:thumbnailUrl]];
    if (data == nil) {
        //本地图片
        data = [NSData dataWithContentsOfFile:thumbnailUrl];
    }
    
    //===//
    WBMessageObject *message = [WBMessageObject message];
    if (text.length > 0) {
        //文本内容
        NSLog(@"WB-文本内容");
        message.text = text;
    }
    
    if (type != WeboShareWithImage){
        //消息的多媒体内容
        NSLog(@"WB-消息的多媒体内容");
        WBBaseMediaObject *media = [WBBaseMediaObject object];
        media.objectID = objectID; //唯一ID
        media.title = title;
        media.description = description;
        
        media.thumbnailData = data; //多媒体内容缩略图
        message.mediaObject = media;
    }
    
    switch (type) {
        case WeboShareWithImage:
        {
            //消息的图片内容
            NSLog(@"WB-消息的图片内容");
            WBImageObject *image = [WBImageObject object];
        
            image.imageData = data;
            message.imageObject = image;
        }
            break;
        case WeboShareWithLink:
        {
            NSLog(@"WB-链接");
            //链接
            WBWebpageObject *pageObj = [WBWebpageObject object];
            pageObj.webpageUrl = actionUrl;
            message.mediaObject = pageObj;
        }
            break;
        case WeboShareWithAudio:
        {
            NSLog(@"WB-音乐地址");
            //音乐地址
            WBMusicObject *musicObj = [WBMusicObject object];
            musicObj.musicUrl = actionUrl;
            musicObj.musicLowBandUrl = musicObj.musicUrl;
            message.mediaObject = musicObj;
        }
            break;
        case WeboShareWithVideo:
        {
            NSLog(@"WB-视频地址");
            //视频地址
            WBVideoObject *videoObj = [WBVideoObject object];
            videoObj.videoUrl = actionUrl;
            videoObj.videoLowBandUrl = videoObj.videoUrl;
            message.mediaObject = videoObj;
        }
            break;
        default:
            break;
    }
    
#pragma mark-----
    WBSendMessageToWeiboRequest *request = [WBSendMessageToWeiboRequest requestWithMessage:message];
    
        if ([WeiboSDK sendRequest:request]) {
            NSLog(@"WB-发送成功");
        }else{
            NSLog(@"WB-发送失败");
        }

}

/**
 收到一个来自微博客户端程序的请求
 
 收到微博的请求后，第三方应用应该按照请求类型进行处理，处理完后必须通过 [WeiboSDK sendResponse:] 将结果回传给微博
 @param request 具体的请求对象
 */
- (void)didReceiveWeiboRequest:(WBBaseRequest *)request{}

/**
 收到一个来自微博客户端程序的响应
 
 收到微博的响应后，第三方应用可以通过响应类型、响应的数据和 WBBaseResponse.userInfo 中的数据完成自己的功能
 @param response 具体的响应对象
 */
- (void)didReceiveWeiboResponse:(WBBaseResponse *)response{
    //微博登录
    if ([response isKindOfClass:[WBAuthorizeResponse class]]) {
        NSLog(@"微博登录");
    }
    //微博分享
    else if([response isKindOfClass:[WBSendMessageToWeiboResponse class]]){
        WBSendMessageToWeiboResponse *sendResp = (WBSendMessageToWeiboResponse *)response;
        
        NSLog(@"微博分享");
        
        @try {
            switch (sendResp.statusCode) {
                case WeiboSDKResponseStatusCodeSuccess:
                {
                    //分享成功
                    //                    WBAuthorizeResponse *authResp = (WBAuthorizeResponse *)response;
                    
                    NSLog(@"微博分享-成功");
                    
                }
                    break;
                case WeiboSDKResponseStatusCodeUserCancel:
                {
                    //用户取消
                    NSLog(@"微博分享-用户取消发送");
                }
                    break;
                case WeiboSDKResponseStatusCodeShareInSDKFailed:
                {
                    //分享失败
                    NSLog(@"微博分享-分享失败");
                }
                    break;
                case WeiboSDKResponseStatusCodeSentFail:
                {
                    //发送失败
                    NSLog(@"微博分享-发送失败");
                }
                    break;
                default:
                    break;
            }
            
        } @catch (NSException *e) {
            NSLog(@"%@",[NSString stringWithFormat:@"WBShare_Exception = %@",e]);
        }
    }
}

//真正进行回应
//执行分享行为
-(void)performActivity{
  
    NSString *WBID = self.shareDic[@"WBID"];
    int type = [self.shareDic[@"type"] intValue];
    NSString *text = self.shareDic[@"text"];
    NSString *title = self.shareDic[@"title"];
    NSString *description = self.shareDic[@"description"];
    NSString *objectID = self.shareDic[@"objectID"];
    NSString *thumbnailUrl = self.shareDic[@"thumbnailUrl"];
    NSString *actionUrl = self.shareDic[@"actionUrl"];
   
      [self SendMessageToWeiboReq:WBID type:type text:text title:title description:description objectID:objectID thumbnailUrl:thumbnailUrl actionUrl:actionUrl];
    
    
   [self activityDidFinish:YES];
}

//处理传过来的分享数据
-(void)dealWithShareData:(NSString *)WBID type:(WeboShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description objectID:(NSString *)objectID thumbnailUrl:(NSString *)thumbnailUrl actionUrl:(NSString *)actionUrl{
    
   self.shareDic = @{@"WBID":WBID,@"type":@(type),@"text":text,@"title":title,@"description":description,@"objectID":objectID,@"thumbnailUrl":thumbnailUrl,@"actionUrl":actionUrl};
    
}
@end
