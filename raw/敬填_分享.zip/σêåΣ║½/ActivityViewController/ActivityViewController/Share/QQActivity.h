//
//  QQActivity.h
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "CustomActivity.h"
#import "AppDelegate.h"

@interface QQActivity : CustomActivity

//0=纯文本 1=纯图片 2=新闻类分享/视频 3=音频
typedef NS_ENUM(NSInteger, QQShareStyle){
    
    QQShareWithText = 0,       /**< 分享纯文本    */
    QQShareWithImage = 1,     /**< 分享纯图片    */
    QQShareWithLinkOrVideo = 2,     /**< 分享新闻类链接或视频    */
    QQShareWithAudio = 3,   /**< 分享音频    */
};

-(void)handleOpenURL:(NSURL *)url; //HandUrl

//处理传过来的分享数据
-(void)dealWithShareData:(NSString *)QQID type:(QQShareStyle)type text:(NSString *)text title:(NSString *)title description:(NSString *)description flashURL:(NSString *)flashURL previewImageURL:(NSString *)previewImageURL actionUrl:(NSString *)actionUrl;

@end
