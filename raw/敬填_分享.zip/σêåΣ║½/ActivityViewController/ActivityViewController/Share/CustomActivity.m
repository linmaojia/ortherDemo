//
//  CustomActivity.m
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "CustomActivity.h"

@interface CustomActivity()
@end

@implementation CustomActivity

//按钮类型（分享按钮：在第一行，彩色，动作按钮：在第二行，黑白）
+(UIActivityCategory)activityCategory{
    return UIActivityCategoryShare;
}

//是否显示分享按钮，这里一般根据用户是否授权,或分享内容是否正确等来决定是否要隐藏分享按钮
-(BOOL)canPerformWithActivityItems:(NSArray *)activityItems{
    return YES;
}

//这是在回应点击消息前的一些准备，譬如你要处理下数据，再做反应。这时候可以把关键的数据存起来。
-(void)prepareWithActivityItems:(NSArray *)activityItems{
    
    for (id activityItem in activityItems) {
        
        if ([activityItem isKindOfClass:[NSString class]]) {
            self.title = activityItem;
        }
        if ([activityItem isKindOfClass:[NSURL class]]) {
            self.url = activityItem;
        }
        if ([activityItem isKindOfClass:[UIImage class]]) {
            self.image = activityItem;
        }
    }
    
}

//真正进行回应
//执行分享行为
-(void)performActivity{
    
    if (self.customBlock) {
        self.customBlock();
    }
    [self activityDidFinish:YES];
}

@end
