//
//  RefreshActivity.h
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "CustomActivity.h"

@interface RefreshActivity : CustomActivity

@end
