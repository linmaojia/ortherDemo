//
//  RefreshActivity.m
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "RefreshActivity.h"

@implementation RefreshActivity

+ (UIActivityCategory)activityCategory {
    return UIActivityCategoryAction;
}

- (UIImage *)activityImage {
    return [UIImage imageNamed:@"share_gray"];
}

- (NSString *)activityTitle {
    return @"刷新";
}

@end
