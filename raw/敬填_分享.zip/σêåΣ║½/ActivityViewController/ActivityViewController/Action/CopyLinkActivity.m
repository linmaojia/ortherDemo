//
//  CopyLinkActivity.m
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "CopyLinkActivity.h"

@implementation CopyLinkActivity

+ (UIActivityCategory)activityCategory {
    return UIActivityCategoryAction;
}

- (UIImage *)activityImage {
    return [UIImage imageNamed:@"share_link"];
}

- (NSString *)activityTitle {
    return @"复制链接";
}

//真正进行回应
-(void)performActivity{
    //复制链接
    UIPasteboard *pab = [UIPasteboard generalPasteboard];
    [pab setString:self.pasteString];
    
    //PasteBlock
    if (self.PasteBlock) {
        self.PasteBlock(pab);
    }
    [self activityDidFinish:YES];
}

@end
