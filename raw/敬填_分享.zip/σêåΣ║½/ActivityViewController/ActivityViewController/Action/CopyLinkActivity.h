//
//  CopyLinkActivity.h
//  ActivityViewController
//
//  Created by JS1-ZJT on 16/6/30.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#import "CustomActivity.h"
#import <UIKit/UIKit.h>

@interface CopyLinkActivity : CustomActivity

//要复制的文本内容
@property (nonatomic,strong)NSString *pasteString;
//block处理(可做复制完成后的其他事件处理)
@property (nonatomic,strong)void(^PasteBlock)(UIPasteboard *pab);

@end
