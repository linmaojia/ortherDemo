//
//  ActivityView.swift
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

import UIKit

class ActivityView: UIView {
    
    var AVController:UIActivityViewController?
    
    //懒加载
    lazy var shareArray:Array<UIActivity> = {
        let SAArray = [UIActivity]()
        return SAArray
    }()
    
    
    //UIActivityViewController
    func activityViewLoad() -> Void {
        
//        let  info = "share test"
//        let image = UIImage(named: "1.png")
//        let  url = NSURL(string: "http://www.baidu.com")
      print("self.shareArray = \(self.shareArray)")
        
        let postItems = []
        AVController = UIActivityViewController(activityItems: postItems as [AnyObject], applicationActivities: self.shareArray)
        
        //pragma mark------
        //iphone设备
        if UI_USER_INTERFACE_IDIOM() == .Phone {
            viewController()?.presentViewController(AVController!, animated: true, completion: nil)
        }else{
           AVController?.modalPresentationStyle = .Popover
           // 设置箭头方向
           AVController?.popoverPresentationController?.permittedArrowDirections = .Up
          //设置参考系
          AVController?.popoverPresentationController?.sourceView = self
         //设置箭头指向的对象
//            AVController?.popoverPresentationController?.sourceRect = ;
         //展现popVC
         viewController()!.presentViewController(AVController!, animated: true, completion: nil)
        }
        
        //只做一次
        var onceToken: dispatch_once_t = 0
        dispatch_once(&onceToken, {
           self.bloakEvent()
        })
        
    }
    
    func bloakEvent() -> Void {
        print("event = \(self.shareArray)")
        
        for activityItem in self.shareArray {
            
            if activityItem.isKindOfClass(WeChatActivity.classForCoder()) {
                let wcActivity = activityItem as! WeChatActivity
                
                wcActivity.customBlock = {
                     print("微信")
                }
            }
            
            if activityItem.isKindOfClass(WeboActivity.classForCoder()) {
                let wbActivity = activityItem as! WeboActivity
                
                wbActivity.customBlock = {
                  print("微博")
                }
            }
            
            if activityItem.isKindOfClass(QQActivity.classForCoder()) {
                let qqActivity = activityItem as! QQActivity
                
                qqActivity.customBlock = {
                  print("QQ")
                }
            }
            
            if activityItem.isKindOfClass(CopyLinkActivity.classForCoder()) {
                let clActivity = activityItem as! CopyLinkActivity
                
                clActivity.customBlock = {
                  print("复制")
                }
            }
            
            if activityItem.isKindOfClass(RefreshActivity.classForCoder()) {
                let rfActivity = activityItem as! RefreshActivity
                rfActivity.customBlock = {
                  print("刷新")
                }
            }
        }
        
    }
    
    //获取父视图控制器
    func viewController() -> UIViewController? {
        
            let next = self.superview
            let nextResponder = next!.nextResponder()
            if nextResponder! is UIViewController {
                print("xxx")
                return (nextResponder as! UIViewController)
            }
        
        
        return nil
    }
    
}
