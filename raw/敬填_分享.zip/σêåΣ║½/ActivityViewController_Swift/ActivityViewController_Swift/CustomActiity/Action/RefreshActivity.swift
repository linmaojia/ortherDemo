//
//  RefreshActivity.swift
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

import UIKit

class RefreshActivity: CustomActivity {

    override class func activityCategory() -> UIActivityCategory{
        return .Action
    }
    
    override func activityImage() -> UIImage? {
        return UIImage(named: "share_gray")
    }
    
    override func activityTitle() -> String? {
        return "刷新"
    }
    
}
