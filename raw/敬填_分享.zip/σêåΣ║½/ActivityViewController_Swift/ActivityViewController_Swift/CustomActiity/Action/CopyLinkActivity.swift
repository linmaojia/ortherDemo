//
//  CopyLinkActivity.swift
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

import UIKit

class CopyLinkActivity: CustomActivity {

    //闭包处理(可做复制完成后的其他事件处理)
    typealias patBlock = (pab:UIPasteboard)->Void
    
    //**< 外部使用 >**//
    var PasteBlock:patBlock?
    var pasteString:String?
    
    override class func activityCategory() -> UIActivityCategory{
      return .Action
    }
    
    override func activityImage() -> UIImage? {
        return UIImage(named: "share_link")
    }
    
    override func activityTitle() -> String? {
        return "复制链接"
    }
    
    override func performActivity() {
        //复制链接
        let pab = UIPasteboard.generalPasteboard()
        pab.string = pasteString
        
        //PasteBlock(回调)
        PasteBlock?(pab: pab)
        
        self.activityDidFinish(true)
    }
    
}
