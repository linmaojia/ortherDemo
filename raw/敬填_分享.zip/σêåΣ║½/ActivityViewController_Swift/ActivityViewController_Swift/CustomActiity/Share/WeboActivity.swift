//
//  WeboActivity.swift
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

import UIKit

class WeboActivity: CustomActivity,WeiboSDKDelegate {

    enum WeboShareStyle:Int {
         /**< 分享图片内容    */
        case WeboShareWithImage = 0
        /**< 分享新闻类链接    */
        case WeboShareWithLink = 1
        /**< 分享音频    */
        case WeboShareWithAudio = 2
        /**< 分享视频    */
        case WeboShareWithVideo = 3
    }
    
    //**< 私有 >**//
    private var shareDic:Dictionary<String,String>?
    
    override func activityImage() -> UIImage? {
        return UIImage(named: "share_weibo")
    }
    
    override func activityTitle() -> String? {
        return "微博"
    }
    
    //handurl
    func handleOpenURL(url:NSURL){
        if WeiboSDK.handleOpenURL(url, delegate: self) {
            print("WB-成功处理跳转")
        }else{
            print("WB-处理跳转失败")
        }
    }
    
    private func SendMessageToWeibo(WBID:String,type:WeboShareStyle,text:String,title:String,description:String,objectID:String,thumbnailUrl:String,actionUrl:String){
        
        WeiboSDK.enableDebugMode(true)
        //注册
        if WeiboSDK.registerApp(WBID) {
            print("微博注册成功")
        }else{
            print("微博注册失败")
        }
        
       //**< 判断检测 >**//
        if !WeiboSDK.isWeiboAppInstalled() {
            print("未安装新浪微博客户端")
            return
        }
        
        if !WeiboSDK.isCanShareInWeiboAPP() {
            print("用户不可以通过微博客户端进行分享")
            return
        }
        
        if !WeiboSDK.isCanSSOInWeiboApp() {
            print("用户不可以使用微博客户端进行SSO授权")
            return
        }
        
        //**< -图片URL(包含缩略图) >**//
        var data = NSData(contentsOfURL: NSURL(string: thumbnailUrl)!)
        if data == nil {
            //本地图片
            data = NSData(contentsOfFile: thumbnailUrl)
        }
        
        //=====//
        let message = WBMessageObject()
        if text.characters.count > 0 {
            //文本内容
            print("WB-文本内容")
            message.text = text
        }
        
        if type != .WeboShareWithImage {
            //消息的多媒体内容
            print("消息的多媒体内容")
            let media = WBBaseMediaObject()
            media.objectID = objectID //唯一ID
            media.title = title
            media.description = description
            
            media.thumbnailData = data //多媒体内容缩略图
            message.mediaObject = media
        }
        
        switch type {
        case .WeboShareWithImage:
            //消息的图片内容
            print("消息的图片内容")
            let image = WBImageObject()
            image.imageData = data
            message.imageObject = image
            
        case .WeboShareWithLink:
            //WB-链接
            print("WB-链接")
            let pageObj = WBWebpageObject()
            pageObj.webpageUrl = actionUrl
            message.mediaObject = pageObj
            
        case .WeboShareWithAudio:
            //音乐地址
            print("音乐地址")
            let musicObj = WBMusicObject()
            musicObj.musicUrl = actionUrl
            musicObj.musicLowBandUrl = musicObj.musicUrl
            message.mediaObject = musicObj
            
        case .WeboShareWithVideo:
            //视频地址
            print("视频地址")
            let videoObj = WBVideoObject()
            videoObj.videoUrl = actionUrl
            videoObj.videoLowBandUrl = videoObj.videoUrl
            message.mediaObject = videoObj
        default:
            break
        }
        
        //**< 发送 >**//
        let request = WBSendMessageToWeiboRequest.requestWithMessage(message) as! WBSendMessageToWeiboRequest
        
        if WeiboSDK.sendRequest(request) {
            print("WB-发送成功")
        }
        else{
           print("WB-发送失败")
        }
    }
    
    /**
     收到一个来自微博客户端程序的请求
     
     收到微博的请求后，第三方应用应该按照请求类型进行处理，处理完后必须通过 [WeiboSDK sendResponse:] 将结果回传给微博
     @param request 具体的请求对象
     */
    func didReceiveWeiboRequest(request: WBBaseRequest!) {}
    
    /**
     收到一个来自微博客户端程序的响应
     
     收到微博的响应后，第三方应用可以通过响应类型、响应的数据和 WBBaseResponse.userInfo 中的数据完成自己的功能
     @param response 具体的响应对象
     */
    func didReceiveWeiboResponse(response: WBBaseResponse!) {
        //微博登录
        if response is WBAuthorizeResponse {
            print("微博登录")
        }
        //微博分享
        else if response is WBSendMessageToWeiboResponse {
            let sendResp = response as! WBSendMessageToWeiboResponse
            
            print("微博分享")
            
            switch sendResp.statusCode {
            case WeiboSDKResponseStatusCode.Success:
                print("微博分享-成功")
            case .UserCancel:
                //用户取消
                print("微博分享-用户取消发送")
            case .ShareInSDKFailed:
                //分享失败
                print("微博分享-分享失败")
            case .SentFail:
                //发送失败
                print("微博分享-发送失败")
            default:
              break
            }
        }
    }
    
    //真正进行回应
    //执行分享行为
    override func performActivity() {
        let WBID = self.shareDic!["WBID"]
        let type = WeboShareStyle(rawValue: Int(self.shareDic!["type"]!)!)
        let text = self.shareDic!["text"]
        let title = self.shareDic!["title"]
        let description = self.shareDic!["description"]
        let objectID = self.shareDic!["objectID"]
        let thumbnailUrl = self.shareDic!["thumbnailUrl"]
        let actionUrl = self.shareDic!["actionUrl"]
        
        self.SendMessageToWeibo(WBID!, type: type!, text: text!, title: title!, description: description!, objectID: objectID!, thumbnailUrl: thumbnailUrl!, actionUrl: actionUrl!)
        
        self.activityDidFinish(true)
    }
    
    //处理传过来的分享数据
    func dealWithShareData(WBID:String,type:WeboShareStyle,text:String,title:String,description:String,objectID:String,thumbnailUrl:String,actionUrl:String){
        
        self.shareDic = ["WBID":WBID,"type":"\(type.rawValue)","text":text,"title":title,"description":description,"objectID":objectID,"thumbnailUrl":thumbnailUrl,"actionUrl":actionUrl]
        
    }
}
