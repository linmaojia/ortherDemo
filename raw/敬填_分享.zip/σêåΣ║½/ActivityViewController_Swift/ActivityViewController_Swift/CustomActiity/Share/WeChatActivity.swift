//
//  WeChatActivity.swift
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

import UIKit

class WeChatActivity: CustomActivity,WXApiDelegate {

    enum WeChatScene:Int {
        /**< 聊天界面    */
        case WeChatSceneSession  = 0
        /**< 朋友圈      */
        case WeChatSceneTimeline = 1
        /**< 收藏        */
        case WeChatSceneFavorite = 2
    }
    
    //0=纯文本 1=纯图片 2=新闻类链接 3=音频 4=视频
    enum WechatShareStyle:Int {
        /**< 分享纯文本    */
        case WeChatShareWithText = 0
        /**< 分享纯图片    */
        case WeChatShareWithImage = 1
        /**< 分享新闻类链接  */
        case WeChatShareWithLink = 2
        /**< 分享音频    */
        case WeChatShareWithAudio = 3
        /**< 分享视频   */
        case WeChatShareWithVideo = 4
    }
    
    //**< 私有 >**//
    private var shareDic:Dictionary<String,String>?
    
    override func activityImage() -> UIImage? {
        return UIImage(named: "share_wechat")
    }
    
    override func activityTitle() -> String? {
        return "微信"
    }
    
    //handurl
    func handleOpenURL(url:NSURL){
        if WXApi.handleOpenURL(url, delegate: self) {
            print("WX-成功处理跳转")
        }else{
           print("WX-处理跳转失败")
        }
    }
    
    //微信分享
    private func SendMessageToWX(WXID:String,type:WechatShareStyle,WCScene:WeChatScene,text:String,title:String,description:String,thumbUrl:String,actionUrl:String) {
        
        //注册
        if WXApi.registerApp(WXID) {
            print("微信注册成功")
        }else{
            print("微信注册失败")
        }
        
        //**< 判断检测 >**//
        if !WXApi.isWXAppInstalled() {
            print("未安装微信客户端，分享失败")
            return
        }
        if !WXApi.isWXAppSupportApi() {
            print("当前微信的版本不支持OpenApi")
            return
        }
        
        //创建发送对象实例
        let sendReq = SendMessageToWXReq()
        
        //scene
        if WCScene.rawValue == Int(WXSceneSession.rawValue)  {
            print("跳转到微信好友")
            sendReq.scene = Int32(WXSceneSession.rawValue) //跳转到微信好友
        }
        else if(WCScene.rawValue == Int(WXSceneTimeline.rawValue)) {
            print("跳转到微信朋友圈")
            sendReq.scene = Int32(WXSceneTimeline.rawValue) //跳转到微信朋友圈
        }
        
        //分享内容对象
        let urlMessage = WXMediaMessage()
        
        if type != .WeChatShareWithText {
            //多媒体内容
            print("WX-多媒体内容")
            sendReq.bText = false
            //创建分享内容对象
            
            urlMessage.title = title //分享标题
            urlMessage.description = description //分享描述
            var data = NSData(contentsOfURL: NSURL(string: thumbUrl)!)
            if data == nil {
                data = NSData(contentsOfFile: thumbUrl)
                print("WX本地地址thumbUrl = \(thumbUrl)")
            }
            
            //进行缩略图片大小检测(KB)
            let thumbImg = dealImageCompress(data!)
            print("size = \(thumbImg.size)")
            
            //**< 分享的缩略图不能超过了32k >**//
            urlMessage.setThumbImage(thumbImg)
        }
        
        //创建多媒体对象
        switch type {
        case .WeChatShareWithText:
            //文本内容
            print("WX-文本内容")
            sendReq.bText = true
            sendReq.text = text
            
        case .WeChatShareWithImage:
             //图片地址
            print("WX-图片地址")
            let imageObj = WXImageObject()
            var data = NSData(contentsOfURL: NSURL(string: actionUrl)!)
            
            if data == nil {
                //本地图片
                data = NSData(contentsOfFile: actionUrl)
                print("WX本地地址actionUrl = \(actionUrl)")
            }
            imageObj.imageData = data;
            urlMessage.mediaObject = imageObj
            
        case .WeChatShareWithLink:
            //链接
            print("WX-链接")
            let pageObj = WXWebpageObject()
            pageObj.webpageUrl = actionUrl
            urlMessage.mediaObject = pageObj
            
        case .WeChatShareWithAudio:
            //音乐地址
            print("WX-音乐地址")
            let musicObj = WXMusicObject()
            musicObj.musicUrl = actionUrl
            musicObj.musicLowBandUrl = musicObj.musicUrl
            urlMessage.mediaObject = musicObj
            
        case .WeChatShareWithVideo:
            //视频地址
            print("WX-视频地址")
            let videoObj = WXVideoObject()
            videoObj.videoUrl = actionUrl
            videoObj.videoLowBandUrl = videoObj.videoUrl //低分辨率的视频url
            urlMessage.mediaObject = videoObj
        default:
            break
        }
        
        sendReq.message = urlMessage
        if WXApi.sendReq(sendReq) {
            print("WX-发送成功")
        }else{
            print("WX-发送失败")
        }
        
       }
    
    /*! @brief 发送一个sendReq后，收到微信的回应
     *
     * 收到一个来自微信的处理结果。调用一次sendReq后会收到onResp。
     * 可能收到的处理结果有SendMessageToWXResp、SendAuthResp等。
     * @param resp具体的回应内容，是自动释放的
     */
    func onResp(resp: BaseResp!) {
        //微信分享/收藏
        if resp is SendMessageToWXResp {
            
            let sendResp = resp as! SendMessageToWXResp
            print("微信分享")
            
            switch sendResp.errCode{
            case WXSuccess.rawValue:
                //成功
                print("微信分享-成功")
            case WXErrCodeUserCancel.rawValue:
                //用户取消
                print("微信分享-用户取消分享")
            case WXErrCodeSentFail.rawValue:
                //发送失败
                print("微信分享-发送失败")
            case WXErrCodeAuthDeny.rawValue:
                //授权失败
                print("微信分享-授权失败")
            default:
                //微信不支持
                print("微信分享-微信不支持")
            }
            
        }
    }
    
    //真正进行回应
    //执行分享行为
    override func performActivity() {
        
        let WXID = self.shareDic!["WXID"];
        let type = WechatShareStyle(rawValue:Int(self.shareDic!["type"]!)!)
        let scene = WeChatScene(rawValue: Int(self.shareDic!["scene"]!)!)
        let text = self.shareDic!["text"];
        let title = self.shareDic!["title"];
        let description = self.shareDic!["description"];
        let thumbUrl = self.shareDic!["thumbUrl"];
        let actionUrl = self.shareDic!["actionUrl"];
        
        self.SendMessageToWX(WXID!, type: type!, WCScene: scene!, text: text!, title: title!, description: description!, thumbUrl: thumbUrl!, actionUrl: actionUrl!)
        
        self.activityDidFinish(true)
    }
    
    //处理图片压缩
    func dealImageCompress(data:NSData) -> UIImage{
        
        let length = data.length/1000
        print("length = \(length)")
        //分享的缩略图不能超过了32k
        if length > 32 {
            return imageCompressForSize(UIImage(data: data)!, size: CGSizeMake(150, 150))
        }
        return UIImage(data: data)!
    }
    
    //压缩方法
    func imageCompressForSize(sourceImage:UIImage,size:CGSize) -> UIImage {
       
        let newImage:UIImage?
        let imageSize = sourceImage.size
        let width = imageSize.width
        let  height = imageSize.height
        let targetWidth = size.width
        let targetHeight = size.height
        var scaleFactor = CGFloat(0.0)
        var scaledWidth = targetWidth
        var scaledHeight = targetHeight
        var thumbnailPoint = CGPointMake(0.0, 0.0)
        if CGSizeEqualToSize(imageSize, size) == false {
            let widthFactor = targetWidth / width
            let heightFactor = targetHeight / height
            if widthFactor > heightFactor {
                scaleFactor = widthFactor
            }else{
                scaleFactor = heightFactor
            }
            scaledWidth = width * scaleFactor
            scaledHeight = height * scaleFactor
            if widthFactor > heightFactor {
                thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5
            }else if widthFactor < heightFactor {
                thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5
            }
        }
        
        UIGraphicsBeginImageContext(size)
        var thumbnailRect = CGRectZero
        thumbnailRect.origin = thumbnailPoint
        thumbnailRect.size.width = scaledWidth
        thumbnailRect.size.height = scaledHeight
        sourceImage.drawInRect(thumbnailRect)
        newImage = UIGraphicsGetImageFromCurrentImageContext()
        if newImage == nil {
            print("scale image fail")
        }
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    //处理传过来的分享数据
    func dealWithShareData(WXID:String,type:WechatShareStyle,scene:WeChatScene,text:String,title:String,description:String,thumbUrl:String,actionUrl:String) {
        
        self.shareDic = ["WXID":WXID,"type":"\(type.rawValue)","scene":"\(scene.rawValue)","text":text,"title":title,"description":description,"thumbUrl":thumbUrl,"actionUrl":actionUrl]

    }
}
