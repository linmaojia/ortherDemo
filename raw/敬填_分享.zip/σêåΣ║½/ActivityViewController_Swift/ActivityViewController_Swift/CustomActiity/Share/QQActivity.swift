//
//  QQActivity.swift
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

import UIKit

class QQActivity: CustomActivity,QQApiInterfaceDelegate,TencentSessionDelegate {

    enum QQShareStyle:Int{
        
        /**< 分享纯文本    */
       case QQShareWithText = 0
        /**< 分享纯图片    */
       case QQShareWithImage = 1
        /**< 分享新闻类链接或视频    */
       case QQShareWithLinkOrVideo = 2
        /**< 分享音频    */
       case QQShareWithAudio = 3
    }
    
    //**< 私有 >**//
    private var auth:TencentOAuth?
    private var shareDic:Dictionary<String,String>?
    
    override func activityImage() -> UIImage? {
        
        return UIImage(named: "share_moments")
    }
    
    override func activityTitle() -> String? {
        return "QQ"
    }
    
    //handurl
    func handleOpenURL(url:NSURL){
        if QQApiInterface.handleOpenURL(url, delegate: self) {
            print("QQ-成功处理跳转")
        }else{
            print("QQ-不支持的请求协议或处理失败")
        }
    }

    //分享方法
   private func SendMessageToQQ(QQID:String,type:QQShareStyle,text:String,title:String,description:String,flashURL:String,previewImageURL:String,actionUrl:String) {
        //注册
        auth = TencentOAuth(appId: QQID, andDelegate: self)
    
        //**< 判断检测 >**//
        if !TencentOAuth.iphoneQQInstalled() {
            print("未安装QQ客户端")
            return
        }
    
        //**< 其他类URL >**//
         //网络地址URL
        var actionURL = NSURL(string: actionUrl)
        if NSData(contentsOfURL: actionURL!) == nil {
            //本地地址URL
            actionURL = NSURL(fileURLWithPath: actionUrl)
        }
    
        //**< 缩略图URL >**//
        //网络地址URL
        var imageURL = NSURL(string: previewImageURL)
        //imgData
        var imgData = NSData(contentsOfURL: imageURL!)
        if imgData == nil {
            //本地地址URL
            imageURL = NSURL(fileURLWithPath: previewImageURL)
            //imgData
            imgData = NSData(contentsOfFile: previewImageURL)
           print("QQ本地地址previewImageURL = \(previewImageURL)")
        }
    
    switch type {
    case .QQShareWithText:
        print("QQ-分享纯文本")
        //纯文本
        let textObj = QQApiTextObject(text: text)
        let req = SendMessageToQQReq(content: textObj)
        //将内容分享到qq
        let resultCode = QQApiInterface.sendReq(req)
        //发送后的返回码
        print("QQSendResultCode = \(resultCode)")
        
    case .QQShareWithImage:
        print("QQ-分享纯图片")
        //纯图片分享
        let imgObj = QQApiImageObject(data: imgData, previewImageData: imgData, title: title, description: description)
        let req = SendMessageToQQReq(content: imgObj)
        //将内容分享到qq
        let resultCode = QQApiInterface.sendReq(req)
        //发送后的返回码
        print("QQSendResultCode = \(resultCode)")
        
    case .QQShareWithLinkOrVideo:
        print("QQ-分享新闻类data")
        //新闻类分享/视频
        let newsObj = QQApiNewsObject(URL: actionURL, title: title, description: description, previewImageData: imgData, targetContentType: QQApiURLTargetTypeNews)
        let req = SendMessageToQQReq(content: newsObj)
        //将内容分享到qq
        let resultCode = QQApiInterface.sendReq(req)
        //发送后的返回码
        print("QQSendResultCode = \(resultCode)")
        
    case .QQShareWithAudio:
        print("QQ-分享音频")
        //音频分享
        let audioObj = QQApiAudioObject(URL: actionURL, title: title, description: description, previewImageData: imgData, targetContentType: QQApiURLTargetTypeAudio)
        
        var flashUrl = NSURL(string: flashURL)
        if NSData(contentsOfURL: flashUrl!) == nil {
            flashUrl = NSURL(fileURLWithPath: flashURL)
        }
        //设置播放流媒体地址
        audioObj.flashURL = flashUrl
        let req = SendMessageToQQReq(content: audioObj)
        //将内容分享到qq
        let resultCode = QQApiInterface.sendReq(req)
        //发送后的返回码
        print("QQSendResultCode = \(resultCode)")
        default:
            break
        }
        
        }
    
    /**
     * 登录成功后的回调
     */
    func tencentDidLogin() {}
    
    /**
     * 登录失败后的回调
     * \param cancelled 代表用户是否主动退出登录
     */
    func tencentDidNotLogin(cancelled: Bool) {}
    
    /**
     * 登录时网络有问题的回调
     */
    func tencentDidNotNetWork() {}
    
    /**
    处理来至QQ的请求
    */
    func onReq(req: QQBaseReq!) {}
    
    /**
    处理来至QQ的响应
    */
    func onResp(resp: QQBaseResp!) {
        
        do{
            switch resp.type {
            case Int32(ESENDMESSAGETOQQRESPTYPE.rawValue):
                let sendResp = resp as! SendMessageToQQResp
                if sendResp.result == "0" {
                    print("QQ分享-成功")
                }else{
                    print("QQ分享-失败")
                }
            default:
                print("未知错误")
                break
            }
        }catch{
            
        }
        
    }
    
    /**
    处理QQ在线状态的回调
    */
    func isOnlineResponse(response: [NSObject : AnyObject]!) {}
    
    override func performActivity() {
        
        let QQID = self.shareDic!["QQID"];
        let type = QQShareStyle(rawValue: Int(self.shareDic!["type"]!)!);
        let text = self.shareDic!["text"];
        let title = self.shareDic!["title"];
        let description = self.shareDic!["description"];
        let flashURL = self.shareDic!["flashURL"];
        let previewImageURL = self.shareDic!["previewImageURL"];
        let actionUrl = self.shareDic!["actionUrl"];
        
        self.SendMessageToQQ(QQID!, type: type!, text: text!, title: title!, description: description!, flashURL: flashURL!, previewImageURL: previewImageURL!, actionUrl: actionUrl!)
        
        self.activityDidFinish(true)
    }
    
    //处理传过来的分享数据
    func dealWithShareData(QQID:String,type:QQShareStyle,text:String,title:String,description:String,flashURL:String,previewImageURL:String,actionUrl:String) {
        
        self.shareDic = ["QQID":QQID,"type":"\(type.rawValue)","text":text,"title":title,"description":description,"flashURL":flashURL,"previewImageURL":previewImageURL,"actionUrl":actionUrl]
        
    }
    
}
