//
//  CustomActivity.swift
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

import UIKit

class CustomActivity: UIActivity {

    var title:NSString?
    var url:NSURL?
    var image:UIImage?
    
    typealias CBlock = ()->Void
    var customBlock:CBlock?
    
    
    //按钮类型（分享按钮：在第一行，彩色，动作按钮：在第二行，黑白）
    override class func activityCategory() -> UIActivityCategory{
        return .Share
    }
    
    //是否显示分享按钮，这里一般根据用户是否授权,或分享内容是否正确等来决定是否要隐藏分享按钮
    override func canPerformWithActivityItems(activityItems: [AnyObject]) -> Bool {
        return true
    }
    
    //这是在回应点击消息前的一些准备，譬如你要处理下数据，再做反应。这时候可以把关键的数据存起来。
    override func prepareWithActivityItems(activityItems: [AnyObject]) {
        
        for activityItem in activityItems {
            if activityItem.isKindOfClass(NSString.classForCoder()) {
                title = (activityItem as! NSString)
            }
            if activityItem.isKindOfClass(NSURL.classForCoder()) {
                url = (activityItem as! NSURL)
            }
            if activityItem.isKindOfClass(UIImage.classForCoder()) {
                image = (activityItem as! UIImage)
            }
        }
        
    }
    
    //真正进行回应
    //执行分享行为
    override func performActivity() {
        
        self.customBlock?()//回调
        self.activityDidFinish(true)
    }
    
}
