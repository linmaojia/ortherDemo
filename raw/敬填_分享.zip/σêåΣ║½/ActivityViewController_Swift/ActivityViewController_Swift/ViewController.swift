//
//  ViewController.swift
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let QQAPPID = "1104648615"
    let WBAPPID = "541684796"
    let WXAPPID = "wx7351c17c054c305a"
    
    var AView:ActivityView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.AView = ActivityView()
        
        let WCActive = WeChatActivity()
        WCActive.dealWithShareData(WXAPPID, type: .WeChatShareWithImage, scene: .WeChatSceneTimeline, text: "我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524 ", title: "口语通", description: "我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524", thumbUrl: "https://ss0.baidu.com/73x1bjeh1BF3odCf/it/u=3205121890,2678579638&fm=96&s=4B86C20BC2660FAD5F800C9601008003", actionUrl: "http://pic13.nipic.com/20110415/1369025_121513630398_2.jpg")
        
        let QActive = QQActivity()
        QActive.dealWithShareData(QQAPPID, type: .QQShareWithImage, text: "我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524 ", title: "口语通", description: "我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524", flashURL: "", previewImageURL: "http://pic13.nipic.com/20110415/1369025_121513630398_2.jpg", actionUrl: "http://kyt.jxt189.com/")
        
        let WBActive = WeboActivity()
        WBActive.dealWithShareData(WBAPPID, type: .WeboShareWithImage, text: "我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524 ", title: "口语通", description: "我在用口语通练习英语口语，整读点读随时听，口语闯关随意说，属于我的个性化口语训练工具！安卓版和苹果版下载地址：http://kyt.jxt189.com/?m=xs9524", objectID: "", thumbnailUrl: "http://pic13.nipic.com/20110415/1369025_121513630398_2.jpg", actionUrl: "http://kyt.jxt189.com/")
        
        let CLActive = CopyLinkActivity()
        CLActive.pasteString = "http://kyt.jxt189.com/"
        
        //闭包实现
        CLActive.PasteBlock = {
          pab in
           print(pab.string)
        }
        
        let RFActive = RefreshActivity()
        
        self.AView!.shareArray += [WCActive,WBActive,QActive,CLActive,RFActive]
        
        self.view.addSubview(self.AView!)
        
    }

    @IBAction func btn(sender: UIButton) {
      self.AView!.activityViewLoad()
    }
}

