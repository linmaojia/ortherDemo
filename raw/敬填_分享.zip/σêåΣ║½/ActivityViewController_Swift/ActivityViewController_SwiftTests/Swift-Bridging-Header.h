//
//  Swift-Bridging-Header.h
//  ActivityViewController_Swift
//
//  Created by Mac on 16/7/2.
//  Copyright © 2016年 JS1-ZJT. All rights reserved.
//

#ifndef Swift_Bridging_Header_h
#define Swift_Bridging_Header_h

#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>
#import "WeiboSDK.h"
#import "WXApi.h"
#import "WechatAuthSDK.h"

#endif /* Swift_Bridging_Header_h */

