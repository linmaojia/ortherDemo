//
//  SCSwipeTableViewCell.h
//  SCSwipeTableViewCell
//
//  Created by Sunc on 15/12/17.
//  Copyright © 2015年 Sunc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SCSwipeTableViewCellDelegate <NSObject>

- (void)SCSwipeTableViewCelldidSelectBtnWithTag:(NSInteger)tag andIndexPath:(NSIndexPath *)indexpath;

//- (void)cellOptionBtnWillShow;
//- (void)cellOptionBtnWillHide;
//- (void)cellOptionBtnDidShow;
//- (void)cellOptionBtnDidHide;

@end

@interface SCSwipeTableViewCell : UITableViewCell

@property (nonatomic, weak)id<SCSwipeTableViewCellDelegate>delegate;

/**
 @author Sunc
 
 存放按钮数组
 */
@property (nonatomic, retain)NSArray *rightBtnArr;

/**
 @author Sunc
 
 when SCSwipeTableViewCell is used, the SCContentView is used instead of contentView of cell itself
 */
@property (nonatomic, retain)UIView *SCContentView;

/**
 @author Sunc
 
 父视图tableView
 */
@property (nonatomic, retain)UITableView *superTableView;


- (id)initWithStyle:(UITableViewCellStyle)style
    reuseIdentifier:(NSString *)reuseIdentifier
           withBtns:(NSArray *)arr
          tableView:(UITableView *)tableView
      cellIndexPath:(NSIndexPath *)indexPath;

@end
